# 🇷🇺 Claude Code - Русская локализация

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Node Version](https://img.shields.io/badge/node-%3E%3D18.0.0-brightgreen)](https://nodejs.org)
[![Platform](https://img.shields.io/badge/platform-Windows-blue)](https://www.microsoft.com/windows)

Полная русификация интерфейса [Claude Code](https://github.com/anthropics/claude-code) CLI для Windows.

## ❓ Как это работает?

После установки у вас будет **две команды**:

| Команда | Язык | Описание |
|---------|------|----------|
| `claude` | 🇬🇧 Английский | Оригинальная версия Claude Code |
| `claude-ru` | 🇷🇺 Русский | Русифицированная версия |

**Обе команды работают одинаково**, разница только в языке интерфейса!

```powershell
# Английская версия (оригинал)
claude --help
# Usage: claude [options] [command] [prompt]

# Русская версия
claude-ru --help
# Использование: claude [опции] [команда] [запрос]
```

## ✨ Возможности

- ✅ Перевод всех сообщений интерфейса
- ✅ Перевод команд и опций в справке
- ✅ Перевод сообщений об ошибках
- ✅ **470+ переведенных фраз** (обновлено!)
- ✅ **Поддержка интерактивного режима через node-pty** (новое!)
- ✅ Полноценный перевод в реальном времени
- ✅ Автоматическая переустановка после обновлений
- ✅ Полная совместимость с оригинальным Claude Code
- ✅ Нулевое влияние на производительность

## 📋 Требования

- **Node.js** 18.0.0 или выше
- **Claude Code** установленный глобально
- **Windows** с PowerShell
- **npm** для установки пакетов

## 🚀 Быстрая установка

### Шаг 1: Установите Claude Code

```bash
npm install -g @anthropic-ai/claude-code
```

Проверьте установку:
```bash
claude --version
# Должно показать: 2.0.76 (Claude Code)
```

### Шаг 2: Скачайте репозиторий

```bash
git clone https://github.com/logansin/claude-code-ru.git
cd claude-code-ru
```

Или скачайте ZIP файл и распакуйте.

### Шаг 3: Запустите установку

```cmd
install.cmd
```

Установщик автоматически:
- Скопирует файлы перевода
- Установит `node-pty` для поддержки интерактивного режима
- Настроит команду `claude-ru` в PowerShell

Или вручную:
```cmd
copy src\claude-ru.cjs %USERPROFILE%\claude-ru-template.cjs
cd %APPDATA%\npm\node_modules\@anthropic-ai\claude-code
npm install node-pty
cd %~dp0
scripts\claude-ru-install.cmd
```

### Шаг 4: Перезапустите PowerShell

```powershell
# Перезапустите PowerShell или выполните:
. $PROFILE
```

### Шаг 5: Проверьте установку

```powershell
claude-ru --help
# Должна показать справку на русском

claude-ru --version
# 2.0.76 (Claude Code)
```

**Готово!** 🎉

## 💻 Использование

### Главный способ: Интерактивная сессия

**Введите команду ОДИН РАЗ и работайте:**

```powershell
PS> claude-ru

# Откроется интерактивная сессия
# Весь интерфейс на русском!

You> привет, как дела?
Claude> [Отвечает...]

You> объясни что такое Node.js
Claude> [Объясняет...]

You> /model opus
# Переключает модель, все на русском

You> создай функцию сортировки
Claude> [Пишет код...]

You> /exit
# Выход из сессии
```

**Вы работаете внутри ОДНОЙ сессии!** Интерфейс полностью на русском.

### Дополнительные команды

```powershell
# Справка
claude-ru --help

# Продолжить предыдущий разговор
claude-ru --continue

# Быстрый запрос (для скриптов, БЕЗ интерактивной сессии)
claude-ru --print "вопрос"
```

### Все опции работают!

```powershell
# Выбор модели
claude-ru --model opus
claude-ru --model sonnet

# Детальный вывод
claude-ru --verbose

# Отладка
claude-ru --debug

# Комбинация опций
claude-ru --model opus --verbose --print "вопрос"
```

### ⚠️ Важно: Команды на английском!

Переводится только **вывод** (интерфейс), а **команды остаются на английском**:

```powershell
# ✅ ПРАВИЛЬНО
claude-ru --help
claude-ru --model opus

# ❌ НЕПРАВИЛЬНО
claude-ru --помощь
claude-ru --модель opus
```

## 🔄 Обновление

После обновления Claude Code русификация пропадает. Восстановите её:

```cmd
scripts\claude-ru-reinstall.cmd
```

### Автоматическая переустановка

Настройте автоматическую проверку через планировщик задач:

```powershell
# Запустите PowerShell от имени администратора
.\scripts\claude-ru-setup-scheduler.ps1
```

Выберите частоту:
- При входе в систему
- Каждый день в 09:00
- Каждый час

## 📁 Структура репозитория

```
claude-code-ru/
├── LICENSE                          # MIT лицензия
├── README.md                        # Этот файл
├── QUICKSTART.md                    # Быстрый старт
├── CONTRIBUTING.md                  # Руководство для контрибьюторов
├── .gitignore                       # Git ignore файл
├── install.cmd                      # Основной установщик
│
├── src/
│   └── claude-ru.cjs                # Основной файл перевода
│
├── scripts/
│   ├── claude-ru-install.cmd        # Скрипт установки
│   ├── claude-ru-reinstall.cmd      # Скрипт переустановки
│   ├── claude-ru-autocheck.ps1      # Автопроверка обновлений
│   └── claude-ru-setup-scheduler.ps1 # Настройка планировщика
│
├── docs/
│   ├── INSTALLATION.md              # Детальная установка
│   ├── USAGE.md                     # Подробное использование
│   └── TROUBLESHOOTING.md           # Решение проблем
│
└── examples/
    ├── basic-usage.ps1              # Примеры использования
    └── advanced-usage.ps1           # Продвинутые примеры
```

## 🔧 Разработка

### Технические детали

Проект использует:
- **node-pty** для создания псевдотерминала (PTY) в Windows
- PTY позволяет перехватывать вывод в интерактивном режиме
- Автоматическое определение режима (интерактивный/неинтерактивный)
- В интерактивном режиме используется PTY для перевода в реальном времени
- В неинтерактивном режиме (`--help`, `-p`) используется обычный pipe

### Добавление новых переводов

Отредактируйте `src/claude-ru.cjs`:

```javascript
const translations = {
  // Добавьте свои переводы
  'Your English phrase': 'Ваша русская фраза',
  // ...
};
```

Текущий словарь содержит **470+ переводов**, включая:
- Команды и опции CLI
- Интерактивные сообщения
- Сообщения об ошибках
- Статусы и прогресс
- Работа с инструментами и разрешениями
- И многое другое

После изменений переустановите:
```cmd
scripts\claude-ru-reinstall.cmd
```

### Тестирование

```powershell
# Проверка перевода
claude-ru --help | Select-String "Использование"

# Проверка ошибок
claude-ru --invalid-option
# Должно показать: "ошибка: неизвестная опция"
```

## 📊 Примеры вывода

### Справка
```
Использование: claude [опции] [команда] [запрос]

Claude Code - запускает интерактивную сессию по умолчанию,
используйте -p/--print для неинтерактивного вывода

Аргументы:
  запрос                                            Ваш запрос

Опции:
  -d, --debug [filter]                              Включить режим отладки
  --verbose                                         Переопределить настройку подробного режима
  -p, --print                                       Вывести ответ и выйти

Команды:
  mcp                                               Настроить и управлять MCP серверами
  plugin                                            Управление плагинами Claude Code
  setup-token                                       Настроить долгоживущий токен аутентификации
```

### Ошибки
```powershell
$ claude-ru --invalid
ошибка: неизвестная опция '--invalid'
```

## 🐛 Устранение проблем

### Команда claude-ru не найдена

```powershell
# Перезагрузите профиль
. $PROFILE

# Или перезапустите PowerShell
```

### Перевод не работает

```powershell
# Проверьте файл перевода
Test-Path "$env:APPDATA\npm\node_modules\@anthropic-ai\claude-code\claude-ru.cjs"

# Переустановите
.\scripts\claude-ru-reinstall.cmd
```

Больше решений в [TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md)

## 🤝 Участие в разработке

Мы приветствуем ваш вклад! См. [CONTRIBUTING.md](CONTRIBUTING.md)

### Как помочь:
- 🐛 Сообщить об ошибке
- 💡 Предложить улучшение
- 🌐 Добавить новые переводы
- 📖 Улучшить документацию

## 📝 История изменений

См. [Releases](https://github.com/logansin/claude-code-ru/releases)

## 📄 Лицензия

MIT License - см. [LICENSE](LICENSE)

## 👥 Авторы

Создано для русскоязычного сообщества разработчиков

## 🔗 Ссылки

- [Claude Code Official](https://github.com/anthropics/claude-code)
- [Claude AI](https://claude.ai)
- [Документация](https://code.claude.com/docs/)

## ⭐ Поддержка проекта

Если проект вам помог, поставьте звезду! ⭐

---

Made with ❤️ for Russian-speaking developers
