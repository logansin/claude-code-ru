# 🚀 Быстрый старт - Claude Code RU

Установка и запуск за **5 минут**.

## 📌 Главное

После установки у вас будет **две команды**:

```
claude     ← оригинал (английский)
claude-ru  ← русская версия
```

**ВАЖНО:** команда с дефисом - `claude-ru`, а НЕ `clauderu`!

---

## ⚡ Установка

### 1️⃣ Установите Claude Code
```bash
npm install -g @anthropic-ai/claude-code
```

### 2️⃣ Скачайте репозиторий
```bash
git clone https://github.com/logansin/claude-code-ru.git
cd claude-code-ru
```

### 3️⃣ Запустите установщик
```cmd
install.cmd
```

### 4️⃣ Перезапустите PowerShell

### 5️⃣ Готово!
```powershell
claude-ru --help
```

---

## 💻 Использование

### 🎯 Главный способ: Интерактивная сессия

**Введите ОДИН РАЗ и работайте:**

```powershell
PS> claude-ru

# Интерактивная сессия запущена!
# Весь интерфейс на русском

You> привет
Claude> Привет! Чем могу помочь?

You> объясни Docker
Claude> [Объяснение...]

You> /model opus
# Меняет модель

You> теперь сложный вопрос...
Claude> [Отвечает...]

You> /exit
# Выход
```

**Вы ввели `claude-ru` только ОДИН РАЗ!**

### Дополнительно: Быстрый запрос

Для скриптов и автоматизации (БЕЗ интерактивной сессии):

```powershell
claude-ru --print "вопрос"
claude-ru -p "краткий ответ"
```

### Справка

```powershell
claude-ru --help    # На русском
claude --help       # На английском (оригинал)
```

---

## 📋 Главное отличие

| Английская версия | Русская версия |
|-------------------|----------------|
| `claude` | `claude-ru` |
| Интерфейс на английском | **Интерфейс на русском** |

**Команды одинаковые, язык разный!**

Просто введите:
- `claude` - для английского интерфейса
- `claude-ru` - для русского интерфейса

---

## ⚠️ Частые ошибки

### ❌ Неправильно:

```powershell
clauderu --help          # Без дефиса - НЕ работает!
claude-ru --помощь       # Команды на русском - НЕ работают!
claude-ru --print        # Без текста - ошибка!
```

### ✅ Правильно:

```powershell
claude-ru --help         # С дефисом
claude-ru --version      # Команды на английском
claude-ru --print "текст" # С текстом после --print
claude-ru                # Без аргументов для интерактивной сессии
```

---

## 🔄 После обновления Claude Code

Русификация пропадет! Восстановите:

```cmd
cd claude-code-ru
scripts\claude-ru-reinstall.cmd
```

---

## 🆘 Проблемы?

### Команда не найдена

```powershell
# Перезагрузите профиль
. $PROFILE
```

### Не переводит

```powershell
# Переустановите
.\scripts\claude-ru-reinstall.cmd
```

### Другие проблемы

См. [TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md)

---

## 📖 Полная документация

- [README.md](README.md) - подробная информация
- [INSTALLATION.md](docs/INSTALLATION.md) - детальная установка
- [USAGE.md](docs/USAGE.md) - все примеры использования

---

**Готово!** Начинайте использовать `claude-ru` 🎉
