# 📖 Руководство по использованию Claude Code RU

Полное руководство по всем возможностям русифицированной версии.

## Основы

### Две команды

После установки у вас есть:

- `claude` - оригинальная английская версия
- `claude-ru` - русифицированная версия

**Обе команды функционально идентичны!** Разница только в языке интерфейса.

---

## Режимы работы

### 1. Интерактивный режим (ОСНОВНОЙ)

**Это главный способ использования!** Введите команду ОДИН РАЗ:

```powershell
PS> claude-ru

# Интерактивная сессия запущена
# Весь интерфейс на русском!

You> привет
Claude> Привет! Чем могу помочь?

You> объясни что такое async/await
Claude> [Подробное объяснение на русском...]

You> /help
# Показывает справку НА РУССКОМ

You> /model opus
# Сообщение: "Модель изменена на opus" (на русском)

You> создай функцию валидации email
Claude> [Пишет код...]

You> отлично, теперь добавь тесты
Claude> [Добавляет тесты...]

You> /clear
# Очищает экран

You> /exit
# Выход из сессии
```

**Вы работаете внутри ОДНОЙ сессии!** Не нужно каждый раз вводить `claude-ru`.

#### Slash-команды в интерактивном режиме:

```
/help      - справка по командам (вывод на русском!)
/model     - сменить модель (сообщения на русском!)
/clear     - очистить экран
/exit      - выйти из сессии
```

**Важно:** Сами команды вводятся на английском, но вывод будет на русском!

### 2. Неинтерактивный режим (--print)

**Дополнительный режим** для скриптов и автоматизации.

Для однократных запросов БЕЗ интерактивной сессии:

```powershell
# Полная форма
claude-ru --print "ваш вопрос"

# Короткая форма
claude-ru -p "ваш вопрос"

# Примеры
claude-ru -p "что такое npm?"
claude-ru -p "объясни async/await"
claude-ru -p "примеры использования git"
```

Вывод сразу в консоль, программа завершается после ответа.

**Когда использовать:**
- В скриптах PowerShell
- Для автоматизации
- Когда нужен только один ответ

**Для обычной работы используйте интерактивный режим!**

---

## Работа с моделями

### Выбор модели

```powershell
# Sonnet (по умолчанию) - быстрая, сбалансированная
claude-ru --model sonnet

# Opus - самая мощная, медленная
claude-ru --model opus

# Haiku - быстрая, для простых задач
claude-ru --model haiku
```

### Конкретная версия модели

```powershell
# Указать полное имя модели
claude-ru --model claude-sonnet-4-5-20250929
```

### Fallback модель

Автоматический переход на другую модель при перегрузке:

```powershell
claude-ru --model opus --fallback-model sonnet --print "вопрос"
```

---

## Работа с сессиями

### Продолжить последний разговор

```powershell
claude-ru --continue
# или
claude-ru -c
```

### Возобновить конкретную сессию

```powershell
# Интерактивный выбор
claude-ru --resume

# Конкретная сессия
claude-ru --resume <session-id>

# С поиском
claude-ru --resume "поисковый запрос"
```

### Создать новую сессию (fork)

```powershell
# Fork при возобновлении
claude-ru --resume <session-id> --fork-session
```

### Отключить сохранение сессий

```powershell
claude-ru --no-session-persistence --print "запрос"
```

---

## Вывод и форматирование

### Форматы вывода

```powershell
# Текст (по умолчанию)
claude-ru --print "вопрос" --output-format text

# JSON (одиночный результат)
claude-ru --print "вопрос" --output-format json

# Stream JSON (потоковый)
claude-ru --print "вопрос" --output-format stream-json
```

### Verbose режим

Подробный вывод с деталями:

```powershell
claude-ru --verbose

# или для конкретного запроса
claude-ru --verbose --print "вопрос"
```

---

## Отладка

### Debug режим

```powershell
# Включить всю отладку
claude-ru --debug

# Фильтр по категориям
claude-ru --debug "api,hooks"

# Исключить категории
claude-ru --debug "!statsig,!file"
```

### MCP debug

```powershell
claude-ru --mcp-debug
```

---

## Работа с инструментами

### Разрешенные инструменты

```powershell
# Только определенные инструменты
claude-ru --allowed-tools "Bash,Edit,Read"

# С фильтрами
claude-ru --allowed-tools "Bash(git:*),Edit"
```

### Запрещенные инструменты

```powershell
# Запретить определенные инструменты
claude-ru --disallowed-tools "Bash(git:*)"
```

### Список доступных инструментов

```powershell
# Только конкретные инструменты (в --print режиме)
claude-ru --tools "Bash,Edit,Read" --print "вопрос"

# Отключить все инструменты
claude-ru --tools "" --print "вопрос"
```

---

## Работа с MCP серверами

### Загрузить MCP конфигурацию

```powershell
# Из файла
claude-ru --mcp-config "path/to/config.json"

# Из JSON строки
claude-ru --mcp-config '{"server":"config"}'

# Несколько конфигураций
claude-ru --mcp-config "config1.json" "config2.json"
```

### Строгий режим MCP

Использовать только указанные MCP серверы:

```powershell
claude-ru --strict-mcp-config --mcp-config "my-servers.json"
```

---

## Настройки и конфигурация

### Загрузить настройки

```powershell
# Из файла
claude-ru --settings "path/to/settings.json"

# Из JSON строки
claude-ru --settings '{"setting":"value"}'
```

### Источники настроек

```powershell
# Загрузить только из определенных источников
claude-ru --setting-sources "user,project"
```

### Дополнительные директории

Разрешить доступ к дополнительным директориям:

```powershell
claude-ru --add-dir "C:\Projects" "C:\Documents"
```

---

## Работа с плагинами

### Загрузить плагины

```powershell
# Из конкретной директории
claude-ru --plugin-dir "path/to/plugins"

# Несколько директорий
claude-ru --plugin-dir "plugins1" "plugins2"
```

### Отключить slash команды

```powershell
claude-ru --disable-slash-commands
```

---

## Интеграция с IDE

### Автоподключение к IDE

```powershell
# Подключиться к IDE автоматически
claude-ru --ide
```

---

## Интеграция с Chrome

### Включить Claude in Chrome

```powershell
claude-ru --chrome
```

### Отключить Claude in Chrome

```powershell
claude-ru --no-chrome
```

---

## Продвинутые примеры

### Комбинация опций

```powershell
# Полный набор опций
claude-ru --model opus `
          --verbose `
          --debug "api" `
          --allowed-tools "Bash,Edit,Read" `
          --mcp-config "servers.json" `
          --settings "my-settings.json" `
          --print "сложный вопрос"
```

### Работа с потоками (pipes)

```powershell
# Входные данные через pipe
Get-Content file.txt | claude-ru --print "проанализируй этот текст"

# Вывод в файл
claude-ru --print "создай список" > output.txt

# Chain с другими командами
claude-ru --print "список файлов" | Out-File -Encoding UTF8 files.txt
```

### Структурированный вывод с JSON Schema

```powershell
# Валидация вывода по JSON Schema
claude-ru --print "данные" --json-schema '{"type":"object","properties":{"name":{"type":"string"}},"required":["name"]}'
```

### Бюджет на API вызовы

```powershell
# Максимальный бюджет
claude-ru --max-budget-usd 5.00 --print "вопрос"
```

---

## Сравнительная таблица

| Функция | Английский | Русский |
|---------|------------|---------|
| Справка | `claude --help` | `claude-ru --help` |
| Версия | `claude --version` | `claude-ru --version` |
| Интерактивная сессия | `claude` | `claude-ru` |
| Быстрый запрос | `claude -p "text"` | `claude-ru -p "текст"` |
| Выбор модели | `claude --model opus` | `claude-ru --model opus` |
| Продолжить разговор | `claude --continue` | `claude-ru --continue` |
| Debug режим | `claude --debug` | `claude-ru --debug` |

**Все опции работают одинаково!**

---

## Советы и трюки

### 1. Алиасы для частых команд

Добавьте в PowerShell профиль:

```powershell
# Короткие алиасы
function cru { claude-ru --print $args }
function cruo { claude-ru --model opus --print $args }
function cruc { claude-ru --continue }

# Использование
cru "быстрый вопрос"
cruo "сложный вопрос"
cruc
```

### 2. Быстрый перевод текста

```powershell
function translate {
    claude-ru --print "Переведи на английский: $args"
}

# Использование
translate "привет мир"
```

### 3. Code review

```powershell
function review {
    Get-Content $args | claude-ru --print "проверь этот код"
}

# Использование
review script.ps1
```

---

## Следующие шаги

- Изучите [примеры](../examples/)
- Настройте [автообновление](INSTALLATION.md#настройка-автообновления-опционально)
- Прочитайте [TROUBLESHOOTING.md](TROUBLESHOOTING.md) при проблемах
