# 📦 Подробная инструкция по установке

Пошаговое руководство по установке Claude Code RU на Windows.

## Системные требования

### Обязательные

- **ОС:** Windows 10/11
- **PowerShell:** 5.1 или выше (или PowerShell Core 7.x)
- **Node.js:** 18.0.0 или выше
- **npm:** 8.0.0 или выше (идет с Node.js)
- **Интернет:** для установки пакетов

### Опциональные

- **Git:** для клонирования репозитория
- **Права администратора:** для настройки планировщика задач

## Проверка требований

```powershell
# Проверьте Node.js
node --version
# Должно быть >= v18.0.0

# Проверьте npm
npm --version
# Должно быть >= 8.0.0

# Проверьте PowerShell
$PSVersionTable.PSVersion
# Должно быть >= 5.1

# Проверьте Git (опционально)
git --version
```

Если что-то отсутствует:
- **Node.js:** скачайте с [nodejs.org](https://nodejs.org/)
- **Git:** скачайте с [git-scm.com](https://git-scm.com/)

## Способ 1: Автоматическая установка (рекомендуется)

### Шаг 1: Установите Claude Code

```bash
npm install -g @anthropic-ai/claude-code
```

Дождитесь завершения установки.

### Шаг 2: Проверьте установку

```bash
claude --version
```

Должно показать: `2.0.76 (Claude Code)` или новее.

### Шаг 3: Скачайте Claude Code RU

**Вариант A: С Git**
```bash
git clone https://github.com/logansin/claude-code-ru.git
cd claude-code-ru
```

**Вариант B: Скачать ZIP**
1. Перейдите на [GitHub репозиторий](https://github.com/logansin/claude-code-ru)
2. Нажмите `Code` → `Download ZIP`
3. Распакуйте в `C:\Users\ВашеИмя\claude-code-ru`

### Шаг 4: Запустите установщик

```cmd
# В папке claude-code-ru
install.cmd
```

Установщик автоматически:
- Скопирует файл перевода в нужное место
- Создаст команду `claude-ru`
- Настроит PowerShell профиль

### Шаг 5: Перезапустите PowerShell

Закройте и откройте новое окно PowerShell.

Или выполните:
```powershell
. $PROFILE
```

### Шаг 6: Проверьте установку

```powershell
# Должна показать справку на русском
claude-ru --help

# Должна показать версию
claude-ru --version
```

✅ **Готово!** Если все работает, установка завершена.

---

## Способ 2: Ручная установка

Если автоматический установщик не работает.

### Шаг 1: Создайте шаблон перевода

Скопируйте файл перевода:

```powershell
# Из репозитория
copy "C:\путь\к\claude-code-ru\src\claude-ru.cjs" "$env:USERPROFILE\claude-ru-template.cjs"
```

### Шаг 2: Скопируйте в директорию Claude Code

```powershell
copy "$env:USERPROFILE\claude-ru-template.cjs" "$env:APPDATA\npm\node_modules\@anthropic-ai\claude-code\claude-ru.cjs"
```

### Шаг 3: Создайте CMD файл

Создайте файл `C:\Users\ВашеИмя\AppData\Roaming\npm\claude-ru.cmd`:

```cmd
@ECHO off
GOTO start
:find_dp0
SET dp0=%~dp0
EXIT /b
:start
SETLOCAL
CALL :find_dp0

IF EXIST "%dp0%\node.exe" (
  SET "_prog=%dp0%\node.exe"
) ELSE (
  SET "_prog=node"
  SET PATHEXT=%PATHEXT:;.JS;=;%
)

endLocal & goto #_undefined_# 2>NUL || title %COMSPEC% & "%_prog%"  "%dp0%\node_modules\@anthropic-ai\claude-code\claude-ru.cjs" %*
```

### Шаг 4: Добавьте функцию в PowerShell профиль

Откройте профиль:
```powershell
notepad $PROFILE
```

Добавьте в конец:
```powershell
# Alias для русской версии Claude Code
function claude-ru {
    node "$env:APPDATA\npm\node_modules\@anthropic-ai\claude-code\claude-ru.cjs" $args
}
```

Сохраните и закройте.

### Шаг 5: Перезагрузите профиль

```powershell
. $PROFILE
```

### Шаг 6: Проверьте

```powershell
claude-ru --version
```

---

## Настройка автообновления (опционально)

Чтобы русификация автоматически восстанавливалась после обновлений Claude Code.

### Вариант 1: Планировщик задач

```powershell
# Запустите PowerShell от имени администратора
cd claude-code-ru
.\scripts\claude-ru-setup-scheduler.ps1
```

Выберите частоту проверки:
- `1` - При входе в систему
- `2` - Каждый день в 09:00
- `3` - Каждый час

### Вариант 2: Ручная переустановка

После каждого обновления Claude Code запускайте:

```cmd
cd claude-code-ru
scripts\claude-ru-reinstall.cmd
```

---

## Проверка установки

### Базовая проверка

```powershell
# 1. Команда существует
Get-Command claude-ru

# 2. Версия
claude-ru --version

# 3. Справка на русском
claude-ru --help | Select-String "Использование"

# 4. Ошибки на русском
claude-ru --invalid 2>&1 | Select-String "ошибка"
```

### Расширенная проверка

```powershell
# Проверка файла перевода
Test-Path "$env:APPDATA\npm\node_modules\@anthropic-ai\claude-code\claude-ru.cjs"
# Должно быть: True

# Проверка шаблона
Test-Path "$env:USERPROFILE\claude-ru-template.cjs"
# Должно быть: True

# Проверка CMD файла
Test-Path "$env:APPDATA\npm\claude-ru.cmd"
# Должно быть: True

# Проверка функции в профиле
Select-String -Path $PROFILE -Pattern "function claude-ru"
# Должно найти строку
```

---

## Удаление

Если нужно удалить русификацию:

```powershell
# 1. Удалите файлы
Remove-Item "$env:APPDATA\npm\claude-ru.cmd"
Remove-Item "$env:APPDATA\npm\node_modules\@anthropic-ai\claude-code\claude-ru.cjs"
Remove-Item "$env:USERPROFILE\claude-ru-template.cjs"
Remove-Item "$env:USERPROFILE\.claude-ru-version"

# 2. Удалите функцию из профиля
notepad $PROFILE
# Удалите секцию "function claude-ru { ... }"

# 3. Перезагрузите профиль
. $PROFILE
```

---

## Troubleshooting

См. [TROUBLESHOOTING.md](TROUBLESHOOTING.md) для решения проблем.

---

## Следующие шаги

- Прочитайте [USAGE.md](USAGE.md) для примеров использования
- Настройте автообновление
- Попробуйте примеры из [examples/](../examples/)
