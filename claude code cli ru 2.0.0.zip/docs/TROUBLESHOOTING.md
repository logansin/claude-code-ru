# 🔧 Решение проблем

Руководство по диагностике и решению типичных проблем.

## Проблемы с установкой

### Claude Code не устанавливается

**Проблема:**
```bash
npm install -g @anthropic-ai/claude-code
# Ошибки при установке
```

**Решения:**

1. **Проверьте версию Node.js**
```bash
node --version
# Должно быть >= 18.0.0
```

Обновите Node.js с [nodejs.org](https://nodejs.org/)

2. **Очистите npm cache**
```bash
npm cache clean --force
npm install -g @anthropic-ai/claude-code
```

3. **Проверьте права доступа**
```bash
# Запустите CMD/PowerShell от имени администратора
npm install -g @anthropic-ai/claude-code
```

### Установщик claude-ru не работает

**Проблема:**
```cmd
install.cmd
# Ошибка или ничего не происходит
```

**Решения:**

1. **Проверьте наличие шаблона**
```powershell
Test-Path "$env:USERPROFILE\claude-ru-template.cjs"
```

Если `False`, скопируйте вручную:
```powershell
copy "путь\к\claude-code-ru\src\claude-ru.cjs" "$env:USERPROFILE\claude-ru-template.cjs"
```

2. **Выполните ручную установку**

См. [INSTALLATION.md - Ручная установка](INSTALLATION.md#способ-2-ручная-установка)

---

## Проблемы с командой claude-ru

### Команда не найдена

**Проблема:**
```powershell
claude-ru --help
# claude-ru : Термин "claude-ru" не распознан...
```

**Решения:**

1. **Перезагрузите профиль PowerShell**
```powershell
. $PROFILE
```

2. **Проверьте наличие функции**
```powershell
Get-Command claude-ru
```

Если не найдена:
```powershell
# Проверьте профиль
notepad $PROFILE

# Должна быть функция:
function claude-ru {
    node "..." $args
}
```

3. **Перезапустите PowerShell**

Закройте и откройте новое окно.

4. **Проверьте CMD файл**
```powershell
Test-Path "$env:APPDATA\npm\claude-ru.cmd"
```

Если отсутствует, создайте через:
```cmd
scripts\claude-ru-install.cmd
```

### Ошибка: "Input must be provided..."

**Проблема:**
```powershell
claude-ru
# Input must be provided either through stdin or as a запрос argument when using --print
```

**Причина:**

Функция `claude-ru` содержит автоматический флаг `--print`.

**Решение:**

1. **Проверьте определение функции**
```powershell
$function:claude-ru
```

2. **Правильное определение:**
```powershell
function claude-ru {
    node "$env:APPDATA\npm\node_modules\@anthropic-ai\claude-code\claude-ru.cjs" $args
}
```

**БЕЗ** `--print` или других флагов!

3. **Исправьте профиль**
```powershell
notepad $PROFILE
# Удалите --print из функции
# Сохраните и перезагрузите:
. $PROFILE
```

---

## Проблемы с переводом

### Интерфейс не переводится

**Проблема:**
```powershell
claude-ru --help
# Usage: claude...  (на английском)
```

**Решения:**

1. **Проверьте файл перевода**
```powershell
Test-Path "$env:APPDATA\npm\node_modules\@anthropic-ai\claude-code\claude-ru.cjs"
```

Если `False`:
```cmd
scripts\claude-ru-reinstall.cmd
```

2. **Проверьте, что используется правильная команда**
```powershell
# НЕ ТАК:
claude --help  # Английская версия

# А ТАК:
claude-ru --help  # Русская версия
```

3. **Переустановите перевод**
```cmd
cd claude-code-ru
scripts\claude-ru-reinstall.cmd
```

### Частичный перевод

**Проблема:**

Некоторые фразы на русском, некоторые на английском.

**Причина:**

Не все фразы добавлены в словарь переводов.

**Решение:**

1. **Найдите непереведенную фразу**
```powershell
claude-ru --help | Select-String "English phrase"
```

2. **Добавьте в словарь**

Откройте `src/claude-ru.cjs`, найдите `translations` и добавьте:
```javascript
'English phrase': 'Русская фраза',
```

3. **Переустановите**
```cmd
scripts\claude-ru-reinstall.cmd
```

4. **Или создайте Issue**

[Сообщите о пропущенной фразе](https://github.com/logansin/claude-code-ru/issues)

---

## Проблемы после обновления

### После обновления Claude Code перевод пропал

**Проблема:**
```bash
npm update -g @anthropic-ai/claude-code
# После этого claude-ru показывает английский интерфейс
```

**Причина:**

Обновление перезаписывает файлы, включая `claude-ru.cjs`.

**Решение:**

```cmd
cd claude-code-ru
scripts\claude-ru-reinstall.cmd
```

**Автоматизация:**

Настройте автоматическую переустановку:
```powershell
# От имени администратора
.\scripts\claude-ru-setup-scheduler.ps1
```

---

## Проблемы с производительностью

### Медленная работа

**Проблема:**

`claude-ru` работает медленнее чем `claude`.

**Причина:**

Перевод добавляет минимальную задержку (~10-20ms) на обработку текста.

**Решение:**

1. **Это нормально**

Задержка незаметна для пользователя.

2. **Используйте оригинальную команду для скриптов**

Для автоматизации используйте `claude` (без перевода):
```bash
claude --print "question"  # Быстрее для скриптов
```

3. **Оптимизация словаря**

Если словарь слишком большой, уберите редко используемые переводы.

---

## Проблемы с кодировкой

### Неправильные символы в выводе

**Проблема:**
```
РЈРїСЂР°РІР»РµРЅРёРµ: claude...
```

**Решения:**

1. **Установите UTF-8 в PowerShell**

Добавьте в профиль (`$PROFILE`):
```powershell
[Console]::OutputEncoding = [Text.UTF8Encoding]::UTF8
$OutputEncoding = [Text.UTF8Encoding]::UTF8
```

2. **Используйте современный терминал**

- **Windows Terminal** (рекомендуется)
- PowerShell 7.x

3. **Проверьте шрифт**

Используйте шрифт с поддержкой кириллицы:
- Consolas
- Cascadia Code
- JetBrains Mono

---

## Проблемы с правами доступа

### Недостаточно прав

**Проблема:**
```
Access denied
Permission denied
```

**Решения:**

1. **Запустите от имени администратора**

Правой кнопкой на PowerShell → "Запуск от имени администратора"

2. **Проверьте ExecutionPolicy**
```powershell
Get-ExecutionPolicy
```

Если `Restricted`:
```powershell
Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
```

---

## Отладка

### Получить подробную информацию

```powershell
# Включить debug режим
claude-ru --debug --help

# Проверить версию
claude-ru --version

# Проверить путь к файлу
Get-Command claude-ru | Format-List

# Содержимое функции
$function:claude-ru
```

### Проверить файлы

```powershell
# Файл перевода
Test-Path "$env:APPDATA\npm\node_modules\@anthropic-ai\claude-code\claude-ru.cjs"

# Шаблон
Test-Path "$env:USERPROFILE\claude-ru-template.cjs"

# CMD файл
Test-Path "$env:APPDATA\npm\claude-ru.cmd"

# Версионный файл
Test-Path "$env:USERPROFILE\.claude-ru-version"
```

### Логи автопроверки

```powershell
# Просмотр лога
Get-Content "$env:USERPROFILE\.claude-ru-autocheck.log"
```

---

## Получение помощи

Если проблема не решена:

1. **Проверьте Issues**

[Существующие проблемы](https://github.com/logansin/claude-code-ru/issues)

2. **Создайте новый Issue**

Укажите:
- Версию Claude Code: `claude --version`
- Версию Node.js: `node --version`
- ОС и версию PowerShell
- Полный текст ошибки
- Что вы уже пробовали

3. **Предоставьте диагностическую информацию**

```powershell
# Соберите информацию
@{
    ClaudeVersion = & claude --version
    NodeVersion = & node --version
    PSVersion = $PSVersionTable.PSVersion
    TranslationFileExists = Test-Path "$env:APPDATA\npm\node_modules\@anthropic-ai\claude-code\claude-ru.cjs"
    CommandExists = (Get-Command claude-ru -ErrorAction SilentlyContinue) -ne $null
} | ConvertTo-Json
```

---

## Известные ограничения

1. **Команды остаются на английском**

Переводится только вывод, не команды.

2. **После обновления нужна переустановка**

Обновление Claude Code сбрасывает русификацию.

3. **Минимальная задержка**

~10-20ms на обработку перевода.

4. **Только Windows**

Текущая версия поддерживает только Windows.

---

## Дополнительные ресурсы

- [INSTALLATION.md](INSTALLATION.md) - инструкции по установке
- [USAGE.md](USAGE.md) - примеры использования
- [CONTRIBUTING.md](../CONTRIBUTING.md) - как помочь проекту
